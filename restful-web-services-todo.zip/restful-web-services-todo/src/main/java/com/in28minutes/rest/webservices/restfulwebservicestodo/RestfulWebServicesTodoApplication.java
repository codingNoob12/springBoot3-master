package com.in28minutes.rest.webservices.restfulwebservicestodo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfulWebServicesTodoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfulWebServicesTodoApplication.class, args);
	}

}
