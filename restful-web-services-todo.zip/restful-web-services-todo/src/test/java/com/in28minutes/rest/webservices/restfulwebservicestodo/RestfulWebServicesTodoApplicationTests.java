package com.in28minutes.rest.webservices.restfulwebservicestodo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulWebServicesTodoApplicationTests {

	@Test
	void contextLoads() {
	}

}
